# Midnight Chess

Xadrez para dois jogadores no mesmo aparelho, no navegador (computador e celular).
Regras oficiais via chess.js, tabuleiro via Chessground, partidas salvas no navegador.

## Como rodar

Requer Node 22+ (os scripts de teste usam padrões glob do `node --test`).

```bash
npm install
npm run dev        # http://localhost:5173 (esbuild, recompila ao salvar)
npm run build      # gera dist/ (index.html, app.js, app.css)
npm run preview    # serve dist/ em http://localhost:4173
```

Verificações:

```bash
npm run typecheck      # tsc estrito
npm test               # testes unitários (regras, estado, persistência) — node:test via tsx
npx playwright install chromium   # uma vez
npm run test:e2e       # testes no navegador real (Chromium): clique, toque, arrastar, responsivo
npm run verify         # tudo, na ordem
npm run verify:vendor  # confirma que chess.js/Chessground estão idênticos ao upstream
```

## O que tem

- Todas as regras via chess.js: lances legais, xeque, mate, roque (com restrições), en passant,
  promoção (dama, torre, bispo, cavalo), afogamento, material insuficiente.
- Empates como nas regras oficiais: **repetição tripla e 50 lances são reivindicáveis**
  (botão aparece quando disponível); **repetição quíntupla e 75 lances encerram sozinhos**.
  Também: empate por acordo e desistência (escolhendo quem desiste).
- Clique/toque nas peças, arrastar e soltar, destinos legais, último lance, xeque em destaque,
  girar tabuleiro, desfazer/refazer, navegação pelos lances (botões, lista e teclas ← → Home End).
- Salvamento automático a cada lance; recupera após recarregar/fechar. Histórico de partidas
  concluídas com reprodução lance a lance, PGN copiável, exclusão com confirmação e estatísticas.
- Layouts próprios: lado a lado no computador; no celular, abas na base, controles de
  desfazer/girar/setas logo abaixo do tabuleiro e lista de lances em faixa compacta.

## Arquitetura

```
src/engine/       regras e estado (puro, sem React): chessLib, position, session, messages
src/persistence/  schema (validação por replay), storage (localStorage versionado), record (PGN, stats)
src/store/        GameStore: estado, autosave, arquivamento no histórico, avisos
src/board/        contrato BoardProps + adaptador do Chessground
src/ui/           React: App, PlayView, ReplayView, HistoryView, diálogos
src/styles/       tokens, base, board, layout, components
vendor/           chess.js e Chessground, sem alteração (checksums em UPSTREAM.sha256)
tests/unit/       regras, sessão (desfazer/refazer/navegação), persistência
tests/e2e/        Playwright no Chromium
```

Decisões que importam:
- O motor é a autoridade: o tabuleiro só mostra destinos e reporta tentativas; qualquer lance
  que o chess.js recusar não altera o estado (e a peça volta ao lugar).
- Uma partida é uma lista de lances (SAN + origem/destino/promoção) a partir da posição
  inicial. Tudo (posição, histórico, repetições) é reconstruído por replay.
- Dados salvos têm `version`; ao carregar, a lista de lances é reproduzida no chess.js e o SAN
  confere. Dados corrompidos ou de versão mais nova são guardados à parte (`...:corrupt`,
  `...:v<N>`) em vez de sobrescritos. Se o navegador bloquear o armazenamento, o jogo segue em
  memória e uma faixa avisa.
- Excluir do histórico a partida recém-terminada é definitivo (flag `archived` na sessão salva).

## Ferramentas: por que esbuild e node:test, e não Vite e Vitest

O ambiente em que o projeto foi construído não tinha rede nem Vite/Vitest/jsdom instalados,
então o build usa esbuild e os testes usam `node:test` (unitários) e Playwright (interface).
Migrar para Vite é direto: `src/main.tsx` e `index.html` são os pontos de entrada padrão.

## `vendor/chess.js/pgn.ts`

O chess.js gera `pgn.js` com o `peggy` no build; o arquivo não vem no repositório. Como o
`peggy` não estava disponível, esse módulo é uma tradução à mão da mesma gramática
(`pgn.peggy`, ao lado). Com acesso ao npm, dá para apagar `vendor/chess.js` e trocar o
import único em `src/engine/chessLib.ts` por `chess.js@1.4.0`.

## Limitações conhecidas

- O tabuleiro não tem entrada de lances por teclado (o Chessground não oferece); os lances
  são por ponteiro/toque. O estado da vez e o resultado são anunciados por região `aria-live`.
- Sem relógio, sem revanche com troca automática de cores, sem exportar/importar PGN de fora.
- Uma aba por vez: duas abas abertas salvando a mesma partida sobrescrevem uma à outra.
- Testado em Chromium (Playwright). Safari e Firefox não foram testados.

## Licença

GPL-3.0-or-later (por causa do Chessground). Veja `LICENSE` e `THIRD_PARTY_LICENSES.md`
**antes de publicar** — há uma pendência sobre a licença das peças cburnett.
