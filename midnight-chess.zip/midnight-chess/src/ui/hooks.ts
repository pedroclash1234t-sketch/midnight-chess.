import { useEffect, useState, useSyncExternalStore } from 'react'
import type { NavTarget } from '../engine/session'
import type { Snapshot } from '../store/gameStore'
import { useStore } from './StoreContext'

export function useSnapshot(): Snapshot {
  const store = useStore()
  return useSyncExternalStore(store.subscribe, store.getSnapshot)
}

export function useReducedMotion(): boolean {
  const query = '(prefers-reduced-motion: reduce)'
  const [reduced, setReduced] = useState(() => typeof matchMedia === 'function' && matchMedia(query).matches)
  useEffect(() => {
    if (typeof matchMedia !== 'function') return
    const mq = matchMedia(query)
    const onChange = () => setReduced(mq.matches)
    mq.addEventListener('change', onChange)
    return () => mq.removeEventListener('change', onChange)
  }, [])
  return reduced
}

const KEY_TARGET: Record<string, NavTarget> = {
  ArrowLeft: 'prev',
  ArrowRight: 'next',
  Home: 'first',
  End: 'last',
}

/** ← → Home End walk through the moves, unless the user is typing or a dialog is open. */
export function useNavKeys(onNav: (t: NavTarget) => void, enabled: boolean) {
  useEffect(() => {
    if (!enabled) return
    const handler = (e: KeyboardEvent) => {
      if (e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return
      const el = e.target as HTMLElement | null
      if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable)) return
      const target = KEY_TARGET[e.key]
      if (!target) return
      e.preventDefault()
      onNav(target)
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [onNav, enabled])
}

const TIP_KEY = 'midnight-chess:tip-dismissed'

/** The short first-run tip: remembered in localStorage when it is available. */
export function useFirstRunTip(): [boolean, () => void] {
  const [visible, setVisible] = useState(() => {
    try {
      return globalThis.localStorage.getItem(TIP_KEY) !== '1'
    } catch {
      return true
    }
  })
  const dismiss = () => {
    setVisible(false)
    try {
      globalThis.localStorage.setItem(TIP_KEY, '1')
    } catch {
      /* the tip simply shows again next time */
    }
  }
  return [visible, dismiss]
}
