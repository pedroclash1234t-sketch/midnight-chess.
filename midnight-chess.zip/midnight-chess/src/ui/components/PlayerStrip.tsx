import type { Color } from '../../engine/chessLib'
import type { Outcome } from '../../engine/types'
import { PieceGlyph } from './PieceGlyph'

interface Props {
  color: Color
  name: string
  /** It is this player's turn in the live position. */
  toMove: boolean
  inCheck: boolean
  outcome: Outcome | null
}

export function PlayerStrip({ color, name, toMove, inCheck, outcome }: Props) {
  const active = toMove && !outcome
  const won = outcome?.winner === color
  const drawn = outcome?.result === '1/2-1/2'
  return (
    <div className="player" data-active={active} data-color={color} aria-label={`${color === 'w' ? 'Brancas' : 'Pretas'}: ${name}`}>
      <PieceGlyph color={color} role="king" />
      <span className="player-name">{name}</span>
      {inCheck && toMove && !outcome && <span className="tag tag-check">Xeque</span>}
      {active && <span className="tag tag-turn">Sua vez</span>}
      {won && <span className="tag tag-win">Vitória</span>}
      {drawn && <span className="tag">Empate</span>}
    </div>
  )
}
