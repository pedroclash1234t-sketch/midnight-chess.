import { reasonLabel, resultShort } from '../../engine/messages'
import type { GameRecord } from '../../persistence/schema'
import type { Stats } from '../../persistence/record'

export const formatDate = (iso: string) =>
  new Date(iso).toLocaleString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })

export function HistoryView({ games, stats, onOpen, onPlay }: { games: readonly GameRecord[]; stats: Stats; onOpen(id: string): void; onPlay(): void }) {
  return (
    <section className="history" aria-labelledby="history-title">
      <h1 className="view-title" id="history-title">
        Partidas anteriores
      </h1>
      {games.length === 0 ? (
        <div className="empty">
          <strong>Nenhuma partida concluída ainda</strong>
          <p>Quando uma partida terminar, ela aparece aqui para você rever lance a lance.</p>
          <button type="button" className="btn btn-primary" onClick={onPlay}>
            Jogar agora
          </button>
        </div>
      ) : (
        <>
          <dl className="stats" aria-label="Estatísticas">
            <Stat label="Partidas" value={stats.total} />
            <Stat label="Vitórias das brancas" value={stats.whiteWins} />
            <Stat label="Vitórias das pretas" value={stats.blackWins} />
            <Stat label="Empates" value={stats.draws} />
            <Stat label="Lances por partida" value={stats.averageMoves.toLocaleString('pt-BR')} />
          </dl>
          <ul className="game-list">
            {games.map((g) => (
              <li key={g.id}>
                <button type="button" className="game-row" data-testid="game-row" onClick={() => onOpen(g.id)}>
                  <span className="game-players">
                    {g.white} contra {g.black}
                  </span>
                  <span className="game-meta">
                    {formatDate(g.endedAt)} · {reasonLabel(g.reason)}
                  </span>
                  <span className="game-end">
                    <span className="chip num">{resultShort(g)}</span>
                    <span className="game-meta num">{g.moveCount} lances</span>
                  </span>
                </button>
              </li>
            ))}
          </ul>
        </>
      )}
    </section>
  )
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="stat">
      <dd className="stat-value num" style={{ margin: 0 }}>
        {value}
      </dd>
      <dt className="stat-label">{label}</dt>
    </div>
  )
}
