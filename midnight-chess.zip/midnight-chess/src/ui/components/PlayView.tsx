import { useCallback, useState } from 'react'
import type { Square } from '../../engine/chessLib'
import { colorName, outcomeDetail, resultLabel } from '../../engine/messages'
import { DEFAULT_PLAYERS } from '../../engine/session'
import type { NavTarget } from '../../engine/session'
import type { PromotionPiece } from '../../engine/types'
import { ChessgroundBoard } from '../../board/ChessgroundBoard'
import { useStore } from '../StoreContext'
import { useFirstRunTip, useNavKeys, useReducedMotion, useSnapshot } from '../hooks'
import { Icon } from '../icons'
import { ConfirmDialog, NewGameDialog, PromotionDialog, ResignDialog } from './Dialogs'
import { MoveList } from './MoveList'
import { NavControls } from './NavControls'
import { PlayerStrip } from './PlayerStrip'

type Dialog = 'new' | 'restart' | 'resign' | 'draw' | null

export function PlayView({ helpOpen }: { helpOpen: boolean }) {
  const store = useStore()
  const snap = useSnapshot()
  const reduced = useReducedMotion()
  const [dialog, setDialog] = useState<Dialog>(null)
  const [promotion, setPromotion] = useState<{ from: Square; to: Square } | null>(null)
  const [resync, setResync] = useState(0)
  const [tipVisible, dismissTip] = useFirstRunTip()

  const { game, view, live, outcome } = snap
  const navigate = useCallback((t: NavTarget) => store.navigate(t), [store])
  useNavKeys(navigate, dialog === null && promotion === null && !helpOpen)

  const onMove = (from: Square, to: Square) => {
    const r = store.move(from, to)
    if (r === 'promotion-required') {
      setPromotion({ from, to })
      return 'pending' as const
    }
    return r === 'ok' ? ('accepted' as const) : ('rejected' as const)
  }
  const choosePromotion = (p: PromotionPiece) => {
    if (promotion) store.move(promotion.from, promotion.to, p)
    setPromotion(null)
  }
  const cancelPromotion = () => {
    setPromotion(null)
    setResync((n) => n + 1)
  }

  const top = game.orientation === 'w' ? 'b' : 'w'
  const strip = (c: 'w' | 'b') => (
    <PlayerStrip color={c} name={game.players[c]} toMove={live.turn === c} inCheck={live.inCheck} outcome={outcome} />
  )
  const viewing = game.viewIndex !== game.moves.length
  const lastSan = game.viewIndex > 0 ? game.moves[game.viewIndex - 1].san : null
  const boardLabel = `Tabuleiro de xadrez. ${outcome ? resultLabel(outcome) : `Vez das ${colorName(live.turn)}`}. ${lastSan ? `Lance exibido: ${lastSan}.` : 'Posição inicial.'}`

  const askRestart = () => (snap.hasProgress ? setDialog('restart') : store.restart())
  const claimLabel = live.claim.threefold ? 'Reivindicar empate: repetição tripla' : 'Reivindicar empate: regra dos 50 lances'

  return (
    <div className="stage" data-testid="play">
      <div className="board-col">
        {strip(top)}
        <ChessgroundBoard
          fen={view.fen}
          orientation={game.orientation}
          turn={view.turn}
          lastMove={view.lastMove}
          check={view.inCheck}
          dests={view.dests}
          interactive={snap.canPlay}
          reducedMotion={reduced}
          resyncToken={resync}
          label={boardLabel}
          onMove={onMove}
        />
        {strip(game.orientation)}
      </div>

      <aside className="panel" aria-label="Painel da partida">
        <div className={`status${outcome ? ' is-over' : ''}`} aria-live="polite">
          {outcome ? (
            <>
              <h1 className="status-title" data-testid="result">
                {resultLabel(outcome)}
              </h1>
              <p className="status-detail">{outcomeDetail(outcome, game.players)}</p>
              <div className="status-actions">
                <button type="button" className="btn btn-primary" onClick={() => setDialog('new')}>
                  <Icon name="plus" /> Nova partida
                </button>
              </div>
            </>
          ) : (
            <>
              <h1 className="status-title" data-testid="turn">
                {game.players[live.turn] === DEFAULT_PLAYERS[live.turn] ? `Vez das ${colorName(live.turn)}` : `Vez de ${game.players[live.turn]}`}
              </h1>
              <p className="status-detail">
                {live.inCheck ? 'Xeque! ' : ''}
                {game.moves.length === 0 ? 'Aguardando o primeiro lance.' : `Jogando com as ${colorName(live.turn)}.`}
              </p>
              {viewing && (
                <div className="status-actions">
                  <button type="button" className="btn" onClick={() => store.navigate('last')}>
                    Voltar ao último lance
                  </button>
                </div>
              )}
              {snap.canClaimDraw && (
                <div className="status-actions">
                  <button type="button" className="btn" onClick={() => store.claimDraw()}>
                    {claimLabel}
                  </button>
                </div>
              )}
            </>
          )}
        </div>

        <MoveList moves={game.moves} current={game.viewIndex} onSelect={(ply) => store.navigate(ply)} />
        <NavControls index={game.viewIndex} total={game.moves.length} onNav={navigate} />

        {tipVisible && (
          <div className="tip">
            <span>Toque numa peça e depois no destino, ou arraste. A partida é salva sozinha.</span>
            <button type="button" className="btn" onClick={dismissTip}>
              Entendi
            </button>
          </div>
        )}

        <div className="actions">
          <button type="button" className="btn" disabled={!snap.canUndo} onClick={() => store.undo()}>
            <Icon name="undo" /> Desfazer
          </button>
          <button type="button" className="btn" disabled={!snap.canRedo} onClick={() => store.redo()}>
            <Icon name="redo" /> Refazer
          </button>
          <button type="button" className="btn" onClick={() => store.flip()}>
            <Icon name="flip" /> Girar
          </button>
        </div>
        <div className="actions-more">
            <button type="button" className="btn" onClick={askRestart}>
              <Icon name="restart" /> Reiniciar
            </button>
            <button type="button" className="btn" onClick={() => setDialog('new')}>
              <Icon name="plus" /> Nova partida
            </button>
            <button type="button" className="btn" disabled={!snap.hasProgress} onClick={() => setDialog('draw')}>
              <Icon name="draw" /> Empate
            </button>
            <button type="button" className="btn btn-danger" disabled={!snap.hasProgress} onClick={() => setDialog('resign')}>
              <Icon name="flag" /> Desistir
            </button>
        </div>
      </aside>

      {dialog === 'new' && (
        <NewGameDialog
          open
          players={game.players}
          hasProgress={snap.hasProgress}
          onStart={(p) => store.newGame(p)}
          onClose={() => setDialog(null)}
        />
      )}
      <ConfirmDialog
        open={dialog === 'restart'}
        title="Reiniciar a partida?"
        message="Os lances jogados até aqui serão descartados. Os jogadores continuam os mesmos."
        confirmLabel="Reiniciar"
        danger
        onConfirm={() => store.restart()}
        onClose={() => setDialog(null)}
      />
      <ConfirmDialog
        open={dialog === 'draw'}
        title="Empate por acordo?"
        message="A partida termina empatada. Confirme só se os dois jogadores concordam."
        confirmLabel="Encerrar em empate"
        onConfirm={() => store.agreeDraw()}
        onClose={() => setDialog(null)}
      />
      <ResignDialog open={dialog === 'resign'} players={game.players} onResign={(c) => store.resign(c)} onClose={() => setDialog(null)} />
      <PromotionDialog open={promotion !== null} color={live.turn} onChoose={choosePromotion} onCancel={cancelPromotion} />
    </div>
  )
}
