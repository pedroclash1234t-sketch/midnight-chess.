import { useCallback, useState } from 'react'
import { useStore } from './StoreContext'
import { useSnapshot } from './hooks'
import { Icon, Logo } from './icons'
import { ConfirmDialog, HelpDialog } from './components/Dialogs'
import { HistoryView } from './components/HistoryView'
import { PlayView } from './components/PlayView'
import { ReplayView } from './components/ReplayView'
import { Toast } from './components/Toast'

type Tab = 'play' | 'history'

export function App() {
  const store = useStore()
  const snap = useSnapshot()
  const [tab, setTab] = useState<Tab>('play')
  const [replayId, setReplayId] = useState<string | null>(null)
  const [helpOpen, setHelpOpen] = useState(false)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [localNotice, setLocalNotice] = useState<{ id: number; kind: 'success' | 'error'; text: string } | null>(null)

  const dismiss = useCallback((id: number) => store.dismissNotice(id), [store])
  const dismissLocal = useCallback(() => setLocalNotice(null), [])

  const record = replayId ? snap.history.find((g) => g.id === replayId) ?? null : null
  const notice = localNotice ?? snap.notice

  const copyPgn = async () => {
    if (!record) return
    try {
      await navigator.clipboard.writeText(record.pgn)
      setLocalNotice({ id: Date.now(), kind: 'success', text: 'PGN copiado.' })
    } catch {
      setLocalNotice({ id: Date.now(), kind: 'error', text: 'Não foi possível copiar. O navegador bloqueou o acesso à área de transferência.' })
    }
  }

  const goTab = (t: Tab) => {
    setTab(t)
    if (t === 'history') setReplayId(null)
  }

  return (
    <>
      <header className="topbar">
        <div className="brand">
          <Logo />
          <span>Midnight Chess</span>
        </div>
        <nav className="tabs" aria-label="Seções">
          <button type="button" className="tab" aria-current={tab === 'play' ? 'page' : undefined} onClick={() => goTab('play')}>
            <Icon name="board" /> Jogar
          </button>
          <button type="button" className="tab" aria-current={tab === 'history' ? 'page' : undefined} onClick={() => goTab('history')}>
            <Icon name="list" /> Partidas{snap.history.length > 0 ? ` (${snap.history.length})` : ''}
          </button>
        </nav>
        <div className="topbar-end">
          <button type="button" className="icon-btn" aria-label="Como jogar" title="Como jogar" onClick={() => setHelpOpen(true)}>
            <Icon name="help" />
          </button>
        </div>
      </header>

      {snap.storage.error && (
        <div className="banner" role="status">
          {snap.storage.error}
        </div>
      )}

      <main className="main">
        {tab === 'play' && <PlayView helpOpen={helpOpen} />}
        {tab === 'history' && !record && (
          <HistoryView games={snap.history} stats={snap.stats} onOpen={setReplayId} onPlay={() => goTab('play')} />
        )}
        {tab === 'history' && record && (
          <ReplayView
            key={record.id}
            record={record}
            dialogOpen={helpOpen || deleteId !== null}
            onBack={() => setReplayId(null)}
            onDelete={() => setDeleteId(record.id)}
            onCopyPgn={copyPgn}
          />
        )}
      </main>

      <Toast notice={notice} onDismiss={localNotice ? dismissLocal : dismiss} />
      <HelpDialog open={helpOpen} onClose={() => setHelpOpen(false)} />
      <ConfirmDialog
        open={deleteId !== null}
        title="Excluir esta partida?"
        message="Ela sai do histórico e não poderá ser recuperada."
        confirmLabel="Excluir"
        danger
        onConfirm={() => {
          if (deleteId) store.deleteGame(deleteId)
          setReplayId(null)
        }}
        onClose={() => setDeleteId(null)}
      />
    </>
  )
}
