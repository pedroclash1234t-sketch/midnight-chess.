import type { Color, Square } from '../engine/chessLib'
import type { Analysis } from '../engine/position'
import {
  agreeDraw,
  canPlay,
  canRedo,
  canUndo,
  claimDraw,
  createGame,
  flip,
  hasProgress,
  isFinished,
  liveAnalysis,
  navigate,
  outcomeOf,
  playMove,
  redo,
  resign,
  undo,
  viewAnalysis,
} from '../engine/session'
import type { GameEnv, GameState, MoveError, NavTarget, Players } from '../engine/session'
import type { Outcome, PromotionPiece } from '../engine/types'
import { buildRecord, computeStats } from '../persistence/record'
import type { Stats } from '../persistence/record'
import type { GameRecord } from '../persistence/schema'
import type { Persistence, SaveResult } from '../persistence/storage'

export type NoticeKind = 'info' | 'success' | 'warning' | 'error'

export interface Notice {
  id: number
  kind: NoticeKind
  text: string
}

export interface Snapshot {
  game: GameState
  /** Position shown on the board (follows the browsing cursor). */
  view: Analysis
  /** Position after the last played move. */
  live: Analysis
  outcome: Outcome | null
  finished: boolean
  canPlay: boolean
  canUndo: boolean
  canRedo: boolean
  canClaimDraw: boolean
  /** True when moves exist and the game is still running (leaving it loses progress). */
  hasProgress: boolean
  history: GameRecord[]
  stats: Stats
  notice: Notice | null
  storage: { available: boolean; error: string | null }
}

export type MoveOutcome = 'ok' | 'promotion-required' | 'rejected'

const MOVE_ERROR_TEXT: Record<MoveError, string> = {
  illegal: 'Esse lance não é permitido.',
  'promotion-required': 'Escolha a peça da promoção.',
  'game-over': 'A partida terminou. Comece uma nova partida para jogar.',
  'not-live': 'Volte ao último lance para continuar jogando.',
}

export class GameStore {
  private state: GameState
  private history: GameRecord[]
  private snapshot!: Snapshot
  private readonly listeners = new Set<() => void>()
  private noticeSeq = 0
  private notice: Notice | null = null
  private saveError: string | null = null
  /** The finished game of the current session is already in the history. */
  private archived = false

  constructor(
    private readonly persistence: Persistence,
    private readonly env: GameEnv,
  ) {
    const loadedHistory = persistence.loadHistory()
    this.history = loadedHistory.games
    const messages = [...loadedHistory.warnings]

    const current = persistence.loadCurrent()
    if (current.status === 'ok') {
      this.state = current.state
      this.archived = current.archived
    } else {
      this.state = createGame(env)
      if (current.status === 'invalid') messages.push(current.message)
    }
    if (messages.length > 0) this.notice = { id: ++this.noticeSeq, kind: 'warning', text: messages.join(' ') }
    if (!persistence.available) {
      this.saveError = 'Este navegador bloqueou o armazenamento: a partida não será recuperada ao recarregar.'
    }
    // A finished game restored from disk may not have reached the history yet
    // (the tab closed between the writes). `archived` stops a game the user
    // deleted from the history from coming back on the next load.
    this.archiveIfFinished()
    if (current.status === 'invalid') this.recordSave(this.persistence.saveCurrent(this.state, this.archived))
    this.rebuild()
  }

  // ---- subscription (useSyncExternalStore) -------------------------------

  subscribe = (listener: () => void): (() => void) => {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  getSnapshot = (): Snapshot => this.snapshot

  // ---- internals ----------------------------------------------------------

  private rebuild() {
    const s = this.state
    const live = liveAnalysis(s)
    this.snapshot = {
      game: s,
      view: viewAnalysis(s),
      live,
      outcome: outcomeOf(s),
      finished: isFinished(s),
      canPlay: canPlay(s),
      canUndo: canUndo(s),
      canRedo: canRedo(s),
      canClaimDraw: !isFinished(s) && (live.claim.threefold || live.claim.fiftyMove),
      hasProgress: hasProgress(s),
      history: this.history,
      stats: computeStats(this.history),
      notice: this.notice,
      storage: { available: this.persistence.available, error: this.saveError },
    }
    for (const l of this.listeners) l()
  }

  private recordSave(result: SaveResult) {
    if (result.ok) {
      if (this.persistence.available) this.saveError = null
    } else {
      this.saveError = result.error
    }
  }

  private archiveIfFinished() {
    const outcome = outcomeOf(this.state)
    if (!outcome || this.archived) return
    // 1) the finished session is on disk (not archived yet), 2) the record, 3) the "archived" mark
    this.recordSave(this.persistence.saveCurrent(this.state, false))
    const record = buildRecord(this.state, outcome, this.env.now())
    this.history = [record, ...this.history.filter((g) => g.id !== record.id)].sort((a, b) => b.endedAt.localeCompare(a.endedAt))
    const saved = this.persistence.upsertGame(record)
    this.recordSave(saved)
    this.archived = true
  }

  private commit(next: GameState) {
    if (next === this.state) return
    if (next.id !== this.state.id) this.archived = false
    this.state = next
    this.archiveIfFinished()
    this.recordSave(this.persistence.saveCurrent(next, this.archived))
    this.rebuild()
  }

  private say(kind: NoticeKind, text: string) {
    this.notice = { id: ++this.noticeSeq, kind, text }
  }

  // ---- actions ------------------------------------------------------------

  move(from: Square, to: Square, promotion?: PromotionPiece): MoveOutcome {
    const result = playMove(this.state, { from, to, promotion })
    if (result.ok) {
      this.notice = null
      this.commit(result.state)
      return 'ok'
    }
    if (result.error === 'promotion-required') return 'promotion-required'
    this.say('error', MOVE_ERROR_TEXT[result.error])
    this.rebuild()
    return 'rejected'
  }

  undo() {
    this.commit(undo(this.state))
  }

  redo() {
    this.commit(redo(this.state))
  }

  navigate(target: NavTarget) {
    this.commit(navigate(this.state, target))
  }

  flip() {
    this.commit(flip(this.state))
  }

  resign(color: Color) {
    this.commit(resign(this.state, color))
  }

  agreeDraw() {
    this.commit(agreeDraw(this.state))
  }

  claimDraw() {
    const next = claimDraw(this.state)
    if (next === this.state) {
      this.say('warning', 'Nenhum empate pode ser reivindicado nesta posição.')
      this.rebuild()
      return
    }
    this.commit(next)
  }

  newGame(players?: Partial<Players>) {
    this.say('info', 'Nova partida iniciada.')
    this.commit(createGame(this.env, players ?? {}, 'w'))
  }

  /** Same players, fresh board. */
  restart() {
    this.newGame(this.state.players)
  }

  deleteGame(id: string) {
    this.history = this.history.filter((g) => g.id !== id)
    this.recordSave(this.persistence.deleteGame(id))
    this.say('success', 'Partida excluída.')
    this.rebuild()
  }

  dismissNotice(id?: number) {
    if (!this.notice || (id !== undefined && this.notice.id !== id)) return
    this.notice = null
    this.rebuild()
  }

  getState(): GameState {
    return this.state
  }
}
