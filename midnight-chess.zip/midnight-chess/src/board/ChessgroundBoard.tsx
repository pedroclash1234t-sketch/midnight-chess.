import { useEffect, useRef } from 'react'
import { Chessground } from '../../vendor/chessground/src/chessground'
import type { Api } from '../../vendor/chessground/src/api'
import type { Config } from '../../vendor/chessground/src/config'
import type { Dests, Key } from '../../vendor/chessground/src/types'
import type { Color, Square } from '../engine/chessLib'
import type { BoardProps } from './types'

const side = (c: Color): 'white' | 'black' => (c === 'w' ? 'white' : 'black')

const NO_DESTS: Dests = new Map()

/** Everything that changes between positions. */
function dynamicConfig(p: BoardProps): Config {
  return {
    fen: p.fen,
    orientation: side(p.orientation),
    turnColor: side(p.turn),
    check: p.check ? side(p.turn) : false,
    lastMove: p.lastMove ? [p.lastMove[0], p.lastMove[1]] : undefined,
    animation: { enabled: !p.reducedMotion },
    movable: {
      color: p.interactive ? side(p.turn) : undefined,
      dests: p.interactive ? (p.dests as unknown as Dests) : NO_DESTS,
    },
  }
}

export function ChessgroundBoard(props: BoardProps) {
  const hostRef = useRef<HTMLDivElement>(null)
  const apiRef = useRef<Api | null>(null)
  const propsRef = useRef(props)

  useEffect(() => {
    propsRef.current = props
  })

  useEffect(() => {
    const host = hostRef.current
    if (!host) return
    const initial = dynamicConfig(propsRef.current)
    const api = Chessground(host, {
      ...initial,
      animation: { enabled: !propsRef.current.reducedMotion, duration: 180 },
      coordinates: true,
      autoCastle: true,
      highlight: { lastMove: true, check: true },
      movable: {
        ...initial.movable,
        free: false,
        showDests: true,
        events: {
          after: (orig: Key, dest: Key) => {
            const verdict = propsRef.current.onMove(orig as Square, dest as Square)
            if (verdict === 'rejected') {
              // let Chessground finish its own event first, then snap back to the engine's position
              setTimeout(() => apiRef.current?.set(dynamicConfig(propsRef.current)), 0)
            }
          },
        },
      },
      premovable: { enabled: false },
      draggable: { enabled: true, showGhost: true },
      selectable: { enabled: true },
      drawable: { enabled: false },
    })
    apiRef.current = api
    const observer = new ResizeObserver(() => api.redrawAll())
    observer.observe(host)
    return () => {
      observer.disconnect()
      api.destroy()
      apiRef.current = null
    }
  }, [])

  const { fen, orientation, turn, check, dests, interactive, reducedMotion, resyncToken } = props
  const from = props.lastMove?.[0]
  const to = props.lastMove?.[1]
  useEffect(() => {
    apiRef.current?.set(dynamicConfig(propsRef.current))
  }, [fen, orientation, turn, check, dests, interactive, reducedMotion, resyncToken, from, to])

  return (
    <div className="board-frame" role="group" aria-label={props.label}>
      <div ref={hostRef} className="cg-wrap" />
    </div>
  )
}
