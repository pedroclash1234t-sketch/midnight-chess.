import type { Color, Square } from './chessLib'

export type PromotionPiece = 'q' | 'r' | 'b' | 'n'

/** One half-move, enough to rebuild a game from the standard start position. */
export interface MoveRecord {
  san: string
  from: Square
  to: Square
  promotion?: PromotionPiece
}

export type GameResult = '1-0' | '0-1' | '1/2-1/2'

export type EndReason =
  | 'checkmate'
  | 'stalemate'
  | 'insufficient-material'
  | 'fivefold-repetition'
  | 'seventy-five-move'
  | 'resignation'
  | 'agreement'
  | 'threefold-claimed'
  | 'fifty-move-claimed'

export interface Outcome {
  result: GameResult
  reason: EndReason
  winner?: Color
}

export const AUTOMATIC_REASONS: readonly EndReason[] = [
  'checkmate',
  'stalemate',
  'insufficient-material',
  'fivefold-repetition',
  'seventy-five-move',
]

export const MANUAL_REASONS: readonly EndReason[] = [
  'resignation',
  'agreement',
  'threefold-claimed',
  'fifty-move-claimed',
]

export const opposite = (c: Color): Color => (c === 'w' ? 'b' : 'w')
