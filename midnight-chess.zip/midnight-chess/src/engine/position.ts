import { Chess } from './chessLib'
import type { Color, Square } from './chessLib'
import type { MoveRecord, Outcome, PromotionPiece } from './types'
import { opposite } from './types'

export class IllegalMoveError extends Error {
  constructor(readonly index: number, readonly move: MoveRecord) {
    super(`Illegal move at ply ${index + 1}: ${move.san}`)
    this.name = 'IllegalMoveError'
  }
}

/** Position identity used for repetition: placement, side, castling, en passant. */
const positionKey = (fen: string) => fen.split(' ').slice(0, 4).join(' ')

export interface Replay {
  chess: Chess
  /** How many times the current position has occurred (>= 1). */
  repetitions: number
}

/**
 * Rebuilds a position from the standard start by playing `moves` through
 * chess.js. Throws IllegalMoveError if the library rejects any of them or if
 * the stored SAN does not match what the library produces.
 */
export function replay(moves: readonly MoveRecord[], upTo: number = moves.length): Replay {
  const chess = new Chess()
  const seen = new Map<string, number>([[positionKey(chess.fen()), 1]])
  let repetitions = 1
  for (let i = 0; i < upTo; i++) {
    const rec = moves[i]
    let played: { san: string } | null = null
    try {
      played = chess.move({ from: rec.from, to: rec.to, promotion: rec.promotion })
    } catch {
      played = null
    }
    if (!played || played.san !== rec.san) throw new IllegalMoveError(i, rec)
    const key = positionKey(chess.fen())
    repetitions = (seen.get(key) ?? 0) + 1
    seen.set(key, repetitions)
  }
  return { chess, repetitions }
}

export interface Analysis {
  fen: string
  turn: Color
  inCheck: boolean
  /** Legal destinations per origin square, straight from chess.js. */
  dests: Map<Square, Square[]>
  legalMoveCount: number
  /** Outcome that ends the game by itself. Claimable draws are NOT here. */
  outcome: Outcome | null
  /** Draws a player may claim; the game goes on until someone does. */
  claim: { threefold: boolean; fiftyMove: boolean }
  lastMove: [Square, Square] | null
  halfmoveClock: number
}

const draw = (reason: Outcome['reason']): Outcome => ({ result: '1/2-1/2', reason })

export function halfmoveClock(chess: Chess): number {
  return parseInt(chess.fen().split(' ')[4] ?? '0', 10) || 0
}

export function automaticOutcome(chess: Chess, repetitions = 1): Outcome | null {
  if (chess.isCheckmate()) {
    const winner = opposite(chess.turn())
    return { result: winner === 'w' ? '1-0' : '0-1', reason: 'checkmate', winner }
  }
  if (chess.isStalemate()) return draw('stalemate')
  if (chess.isInsufficientMaterial()) return draw('insufficient-material')
  // FIDE: fivefold repetition and the 75-move rule end the game without a claim.
  if (repetitions >= 5) return draw('fivefold-repetition')
  if (halfmoveClock(chess) >= 150) return draw('seventy-five-move')
  return null
}

export function analyzeChess(
  chess: Chess,
  repetitions = 1,
  lastMove: [Square, Square] | null = null,
): Analysis {
  const dests = new Map<Square, Square[]>()
  let legalMoveCount = 0
  for (const m of chess.moves({ verbose: true })) {
    legalMoveCount++
    const list = dests.get(m.from)
    if (!list) dests.set(m.from, [m.to])
    else if (!list.includes(m.to)) list.push(m.to)
  }
  const outcome = automaticOutcome(chess, repetitions)
  return {
    fen: chess.fen(),
    turn: chess.turn(),
    inCheck: chess.isCheck(),
    dests,
    legalMoveCount,
    outcome,
    claim: {
      threefold: !outcome && chess.isThreefoldRepetition(),
      fiftyMove: !outcome && chess.isDrawByFiftyMoves(),
    },
    lastMove,
    halfmoveClock: halfmoveClock(chess),
  }
}

const cache = new WeakMap<readonly MoveRecord[], Map<number, Analysis>>()

/** Analysis of the position after `index` half-moves (memoised per move list). */
export function analyzeMoves(moves: readonly MoveRecord[], index: number = moves.length): Analysis {
  let byIndex = cache.get(moves)
  const hit = byIndex?.get(index)
  if (hit) return hit
  const { chess, repetitions } = replay(moves, index)
  const last = index > 0 ? moves[index - 1] : null
  const analysis = analyzeChess(chess, repetitions, last ? [last.from, last.to] : null)
  if (!byIndex) {
    byIndex = new Map()
    cache.set(moves, byIndex)
  }
  byIndex.set(index, analysis)
  return analysis
}

export function needsPromotion(chess: Chess, from: Square, to: Square): boolean {
  return chess.moves({ square: from, verbose: true }).some((m) => m.to === to && !!m.promotion)
}

export function isPromotionPiece(p: string | undefined): p is PromotionPiece {
  return p === 'q' || p === 'r' || p === 'b' || p === 'n'
}
