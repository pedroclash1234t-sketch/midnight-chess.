import { analyzeMoves, needsPromotion, replay } from './position'
import type { Analysis } from './position'
import type { Color, Square } from './chessLib'
import { opposite } from './types'
import type { MoveRecord, Outcome, PromotionPiece } from './types'

export interface Players {
  w: string
  b: string
}

/**
 * Whole state of one game. Immutable: every operation returns a new object.
 * `moves` is the played line; `redo` holds undone moves (last item = next redo);
 * `viewIndex` is only the browsing cursor and never changes the game itself.
 */
export interface GameState {
  id: string
  startedAt: string
  players: Players
  moves: MoveRecord[]
  redo: MoveRecord[]
  viewIndex: number
  orientation: Color
  manualOutcome: Outcome | null
}

export interface GameEnv {
  now(): Date
  newId(): string
}

export const DEFAULT_PLAYERS: Players = { w: 'Brancas', b: 'Pretas' }
export const MAX_NAME_LENGTH = 24

export function cleanName(raw: string, fallback: string): string {
  const name = raw.replace(/\s+/g, ' ').trim().slice(0, MAX_NAME_LENGTH)
  return name || fallback
}

export function createGame(env: GameEnv, players: Partial<Players> = {}, orientation: Color = 'w'): GameState {
  return {
    id: env.newId(),
    startedAt: env.now().toISOString(),
    players: {
      w: cleanName(players.w ?? '', DEFAULT_PLAYERS.w),
      b: cleanName(players.b ?? '', DEFAULT_PLAYERS.b),
    },
    moves: [],
    redo: [],
    viewIndex: 0,
    orientation,
    manualOutcome: null,
  }
}

/** Analysis of the live (last played) position. */
export const liveAnalysis = (s: GameState): Analysis => analyzeMoves(s.moves, s.moves.length)

/** Analysis of the position currently shown on the board. */
export const viewAnalysis = (s: GameState): Analysis => analyzeMoves(s.moves, s.viewIndex)

export const outcomeOf = (s: GameState): Outcome | null => s.manualOutcome ?? liveAnalysis(s).outcome

export const isFinished = (s: GameState): boolean => outcomeOf(s) !== null
export const isLive = (s: GameState): boolean => s.viewIndex === s.moves.length
export const canPlay = (s: GameState): boolean => isLive(s) && !isFinished(s)
export const canUndo = (s: GameState): boolean => s.moves.length > 0 && !isFinished(s)
export const canRedo = (s: GameState): boolean => s.redo.length > 0 && !isFinished(s)

export type MoveError = 'illegal' | 'promotion-required' | 'game-over' | 'not-live'

export interface MoveInput {
  from: Square
  to: Square
  promotion?: PromotionPiece
}

export type MoveResult = { ok: true; state: GameState } | { ok: false; error: MoveError }

/** chess.js is the only authority: anything it rejects leaves the state untouched. */
export function playMove(state: GameState, input: MoveInput): MoveResult {
  if (!isLive(state)) return { ok: false, error: 'not-live' }
  if (isFinished(state)) return { ok: false, error: 'game-over' }
  const { chess } = replay(state.moves)
  if (needsPromotion(chess, input.from, input.to) && !input.promotion) {
    return { ok: false, error: 'promotion-required' }
  }
  let played
  try {
    played = chess.move({ from: input.from, to: input.to, promotion: input.promotion })
  } catch {
    return { ok: false, error: 'illegal' }
  }
  if (!played) return { ok: false, error: 'illegal' }
  const record: MoveRecord = { san: played.san, from: played.from, to: played.to }
  if (played.promotion) record.promotion = played.promotion as PromotionPiece
  const moves = [...state.moves, record]
  return { ok: true, state: { ...state, moves, redo: [], viewIndex: moves.length } }
}

export function undo(state: GameState): GameState {
  if (!canUndo(state)) return state
  const moves = state.moves.slice(0, -1)
  const undone = state.moves[state.moves.length - 1]
  return { ...state, moves, redo: [...state.redo, undone], viewIndex: moves.length }
}

export function redo(state: GameState): GameState {
  if (!canRedo(state)) return state
  const next = state.redo[state.redo.length - 1]
  const moves = [...state.moves, next]
  return { ...state, moves, redo: state.redo.slice(0, -1), viewIndex: moves.length }
}

export type NavTarget = 'first' | 'prev' | 'next' | 'last' | number

export function navigate(state: GameState, target: NavTarget): GameState {
  const last = state.moves.length
  const raw =
    target === 'first' ? 0 : target === 'last' ? last : target === 'prev' ? state.viewIndex - 1 : target === 'next' ? state.viewIndex + 1 : target
  const viewIndex = Math.max(0, Math.min(last, Math.trunc(raw)))
  return viewIndex === state.viewIndex ? state : { ...state, viewIndex }
}

export const flip = (s: GameState): GameState => ({ ...s, orientation: opposite(s.orientation) })

export function resign(state: GameState, color: Color): GameState {
  if (isFinished(state)) return state
  const winner = opposite(color)
  return {
    ...state,
    viewIndex: state.moves.length,
    manualOutcome: { result: winner === 'w' ? '1-0' : '0-1', reason: 'resignation', winner },
  }
}

export function agreeDraw(state: GameState): GameState {
  if (isFinished(state)) return state
  return { ...state, viewIndex: state.moves.length, manualOutcome: { result: '1/2-1/2', reason: 'agreement' } }
}

/** Draw claim under the threefold-repetition or 50-move rule, only when available. */
export function claimDraw(state: GameState): GameState {
  if (isFinished(state)) return state
  const { claim } = liveAnalysis(state)
  if (!claim.threefold && !claim.fiftyMove) return state
  return {
    ...state,
    viewIndex: state.moves.length,
    manualOutcome: {
      result: '1/2-1/2',
      reason: claim.threefold ? 'threefold-claimed' : 'fifty-move-claimed',
    },
  }
}

export const hasProgress = (s: GameState): boolean => s.moves.length > 0 && !isFinished(s)

export function fenAt(state: GameState, index: number): string {
  return analyzeMoves(state.moves, index).fen
}

