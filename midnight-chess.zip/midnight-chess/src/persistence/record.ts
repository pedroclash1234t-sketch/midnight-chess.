import { Chess } from '../engine/chessLib'
import { analyzeMoves } from '../engine/position'
import type { GameState } from '../engine/session'
import type { Outcome } from '../engine/types'
import type { GameRecord } from './schema'

const pgnSafe = (s: string) => s.replace(/["\\\[\]\r\n]/g, "'")
const pgnDate = (iso: string) => {
  const d = new Date(iso)
  const p = (n: number) => String(n).padStart(2, '0')
  return `${d.getUTCFullYear()}.${p(d.getUTCMonth() + 1)}.${p(d.getUTCDate())}`
}

export function buildPgn(state: GameState, outcome: Outcome): string {
  const chess = new Chess()
  for (const m of state.moves) chess.move({ from: m.from, to: m.to, promotion: m.promotion })
  chess.setHeader('Event', 'Midnight Chess')
  chess.setHeader('Site', 'Midnight Chess (local)')
  chess.setHeader('Date', pgnDate(state.startedAt))
  chess.setHeader('Round', '-')
  chess.setHeader('White', pgnSafe(state.players.w))
  chess.setHeader('Black', pgnSafe(state.players.b))
  chess.setHeader('Result', outcome.result)
  return chess.pgn()
}

export function buildRecord(state: GameState, outcome: Outcome, endedAt: Date): GameRecord {
  return {
    id: state.id,
    startedAt: state.startedAt,
    endedAt: endedAt.toISOString(),
    white: state.players.w,
    black: state.players.b,
    result: outcome.result,
    reason: outcome.reason,
    moves: state.moves.map((m) => ({ ...m })),
    plies: state.moves.length,
    moveCount: Math.ceil(state.moves.length / 2),
    pgn: buildPgn(state, outcome),
    finalFen: analyzeMoves(state.moves).fen,
  }
}

export interface Stats {
  total: number
  whiteWins: number
  blackWins: number
  draws: number
  averageMoves: number
}

export function computeStats(games: readonly GameRecord[]): Stats {
  const total = games.length
  const whiteWins = games.filter((g) => g.result === '1-0').length
  const blackWins = games.filter((g) => g.result === '0-1').length
  const draws = total - whiteWins - blackWins
  const averageMoves = total === 0 ? 0 : Math.round((games.reduce((a, g) => a + g.moveCount, 0) / total) * 10) / 10
  return { total, whiteWins, blackWins, draws, averageMoves }
}
