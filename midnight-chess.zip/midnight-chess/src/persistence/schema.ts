import { analyzeMoves, replay, IllegalMoveError } from '../engine/position'
import { cleanName, MAX_NAME_LENGTH } from '../engine/session'
import type { GameState } from '../engine/session'
import { AUTOMATIC_REASONS, MANUAL_REASONS } from '../engine/types'
import type { EndReason, GameResult, MoveRecord, Outcome } from '../engine/types'
import type { Color, Square } from '../engine/chessLib'

/** Bump when the stored shape changes and add a migration in `migrate`. */
export const SCHEMA_VERSION = 1

export interface GameRecord {
  id: string
  startedAt: string
  endedAt: string
  white: string
  black: string
  result: GameResult
  reason: EndReason
  /** Half-moves; enough to rebuild the whole game. */
  moves: MoveRecord[]
  /** Number of half-moves. */
  plies: number
  /** Number of full moves (ceil(plies / 2)). */
  moveCount: number
  pgn: string
  finalFen: string
}

export interface StoredSession {
  version: number
  savedAt: string
  /** The finished game of this session already reached the history (so deleting it there is final). */
  archived?: boolean
  session: {
    id: string
    startedAt: string
    players: { w: string; b: string }
    moves: MoveRecord[]
    redo: MoveRecord[]
    orientation: Color
    manualOutcome: Outcome | null
  }
}

export interface StoredHistory {
  version: number
  games: unknown[]
}

export type Parsed<T> = { ok: true; value: T } | { ok: false; error: string }

const fail = (error: string): { ok: false; error: string } => ({ ok: false, error })

const isObject = (v: unknown): v is Record<string, unknown> => typeof v === 'object' && v !== null && !Array.isArray(v)
const SQUARE = /^[a-h][1-8]$/
const isIso = (v: unknown): v is string => typeof v === 'string' && v.length <= 40 && !Number.isNaN(Date.parse(v))
const isId = (v: unknown): v is string => typeof v === 'string' && v.length > 0 && v.length <= 100
const RESULTS: readonly string[] = ['1-0', '0-1', '1/2-1/2']
const ALL_REASONS: readonly string[] = [...AUTOMATIC_REASONS, ...MANUAL_REASONS]

function parseMove(v: unknown): MoveRecord | null {
  if (!isObject(v)) return null
  const { san, from, to, promotion } = v
  if (typeof san !== 'string' || san.length === 0 || san.length > 12) return null
  if (typeof from !== 'string' || !SQUARE.test(from)) return null
  if (typeof to !== 'string' || !SQUARE.test(to)) return null
  if (promotion !== undefined && !(promotion === 'q' || promotion === 'r' || promotion === 'b' || promotion === 'n')) return null
  const rec: MoveRecord = { san, from: from as Square, to: to as Square }
  if (promotion !== undefined) rec.promotion = promotion
  return rec
}

function parseMoves(v: unknown, label: string): Parsed<MoveRecord[]> {
  if (!Array.isArray(v) || v.length > 2000) return fail(`${label}: lista de lances inválida`)
  const out: MoveRecord[] = []
  for (const item of v) {
    const m = parseMove(item)
    if (!m) return fail(`${label}: lance inválido`)
    out.push(m)
  }
  return { ok: true, value: out }
}

function parseOutcome(v: unknown): Parsed<Outcome> {
  if (!isObject(v)) return fail('desfecho inválido')
  if (typeof v.result !== 'string' || !RESULTS.includes(v.result)) return fail('resultado inválido')
  if (typeof v.reason !== 'string' || !ALL_REASONS.includes(v.reason)) return fail('motivo de término inválido')
  const out: Outcome = { result: v.result as GameResult, reason: v.reason as EndReason }
  if (v.winner === 'w' || v.winner === 'b') out.winner = v.winner
  return { ok: true, value: out }
}

function parseNames(v: unknown): Parsed<{ w: string; b: string }> {
  if (!isObject(v) || typeof v.w !== 'string' || typeof v.b !== 'string') return fail('nomes dos jogadores inválidos')
  if (v.w.length > MAX_NAME_LENGTH * 4 || v.b.length > MAX_NAME_LENGTH * 4) return fail('nomes dos jogadores inválidos')
  return { ok: true, value: { w: cleanName(v.w, 'Brancas'), b: cleanName(v.b, 'Pretas') } }
}

/** Replays `moves` through chess.js: the stored line must be a legal game. */
function checkReplay(moves: MoveRecord[], label: string): Parsed<true> {
  try {
    replay(moves)
    return { ok: true, value: true }
  } catch (e) {
    return fail(`${label}: ${e instanceof IllegalMoveError ? e.message : 'não foi possível reproduzir os lances'}`)
  }
}

export function parseSession(raw: unknown): Parsed<GameState> {
  if (!isObject(raw) || !isObject(raw.session)) return fail('formato inesperado')
  const s = raw.session
  if (!isId(s.id) || !isIso(s.startedAt)) return fail('identificação da partida inválida')
  const players = parseNames(s.players)
  if (!players.ok) return players
  const moves = parseMoves(s.moves, 'lances')
  if (!moves.ok) return moves
  const redo = parseMoves(s.redo ?? [], 'refazer')
  if (!redo.ok) return redo
  if (s.orientation !== 'w' && s.orientation !== 'b') return fail('orientação inválida')
  let manualOutcome: Outcome | null = null
  if (s.manualOutcome !== null && s.manualOutcome !== undefined) {
    const o = parseOutcome(s.manualOutcome)
    if (!o.ok) return o
    if (!MANUAL_REASONS.includes(o.value.reason)) return fail('desfecho manual inválido')
    manualOutcome = o.value
  }
  const line = checkReplay(moves.value, 'lances')
  if (!line.ok) return line
  // The redo stack must continue the line legally (its last item is played first).
  const redoLine = checkReplay([...moves.value, ...[...redo.value].reverse()], 'refazer')
  if (!redoLine.ok) return redoLine
  const state: GameState = {
    id: s.id,
    startedAt: s.startedAt,
    players: players.value,
    moves: moves.value,
    redo: redo.value,
    viewIndex: moves.value.length,
    orientation: s.orientation,
    manualOutcome,
  }
  const auto = analyzeMoves(state.moves).outcome
  if (manualOutcome && auto) return fail('partida já terminada antes do desfecho manual')
  if (manualOutcome && redo.value.length > 0) return fail('partida terminada com lances para refazer')
  return { ok: true, value: state }
}

export function parseGameRecord(raw: unknown): Parsed<GameRecord> {
  if (!isObject(raw)) return fail('registro inválido')
  if (!isId(raw.id)) return fail('identificador inválido')
  if (!isIso(raw.startedAt) || !isIso(raw.endedAt)) return fail('datas inválidas')
  if (typeof raw.white !== 'string' || typeof raw.black !== 'string') return fail('nomes inválidos')
  if (typeof raw.pgn !== 'string' || raw.pgn.length > 200_000) return fail('PGN inválido')
  if (typeof raw.finalFen !== 'string') return fail('posição final inválida')
  const o = parseOutcome({ result: raw.result, reason: raw.reason, winner: raw.winner })
  if (!o.ok) return o
  const moves = parseMoves(raw.moves, 'lances')
  if (!moves.ok) return moves
  const line = checkReplay(moves.value, 'lances')
  if (!line.ok) return line
  const end = analyzeMoves(moves.value)
  if (raw.plies !== moves.value.length || raw.moveCount !== Math.ceil(moves.value.length / 2)) {
    return fail('contagem de lances inconsistente')
  }
  if (end.fen !== raw.finalFen) return fail('posição final não confere com os lances')
  const reason = o.value.reason
  if (AUTOMATIC_REASONS.includes(reason)) {
    if (!end.outcome || end.outcome.reason !== reason || end.outcome.result !== o.value.result) {
      return fail('resultado não confere com os lances')
    }
  } else if (end.outcome) {
    return fail('desfecho manual em partida já terminada')
  }
  return {
    ok: true,
    value: {
      id: raw.id,
      startedAt: raw.startedAt,
      endedAt: raw.endedAt,
      white: cleanName(raw.white, 'Brancas'),
      black: cleanName(raw.black, 'Pretas'),
      result: o.value.result,
      reason,
      moves: moves.value,
      plies: moves.value.length,
      moveCount: Math.ceil(moves.value.length / 2),
      pgn: raw.pgn,
      finalFen: raw.finalFen,
    },
  }
}

/**
 * Brings stored data of an older schema up to SCHEMA_VERSION.
 * There is only version 1 today; add one step per future bump, e.g.
 * `if (version === 1) { data = {...}; version = 2 }`.
 */
export function migrate(data: Record<string, unknown>): Parsed<Record<string, unknown>> {
  const version = data.version
  if (typeof version !== 'number' || !Number.isInteger(version) || version < 1) return fail('versão ausente ou inválida')
  if (version > SCHEMA_VERSION) return fail(`dados da versão ${version}, mais nova que a suportada (${SCHEMA_VERSION})`)
  return { ok: true, value: data }
}
